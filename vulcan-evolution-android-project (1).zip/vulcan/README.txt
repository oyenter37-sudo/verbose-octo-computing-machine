Vulcan Evolution: Android-проект (WebView, игра лежит в app/src/main/assets/index.html)

Как получить APK:
1) Android Studio: File > Open > эта папка. Дождись синхронизации.
   Build > Build APK(s). Готовый файл: app/build/outputs/apk/debug/app-debug.apk
2) Командной строкой (нужны JDK 17 и Android SDK 34):
   gradle assembleDebug   (Gradle 8.5+)

Чтобы обновить игру: замени app/src/main/assets/index.html и собери заново.
Иконка: app/src/main/res/mipmap-*/ (адаптивная + круглая).

Без Android Studio (через GitHub, бесплатно):
1) Создай репозиторий на github.com, загрузи в него всё содержимое этой папки (включая скрытую папку .github).
2) Вкладка Actions > Build APK > дождись зелёной галочки (3-5 минут).
3) Открой запуск > внизу Artifacts > VulcanEvolution-apk > скачай zip, внутри app-debug.apk.
